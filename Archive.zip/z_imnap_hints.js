// 1

Object.values(obj) // – возвращает массив значений.

let user = {
  name: "John",
  age: 30
};

Object.values(user) = ["John", 30];

// --------------------------------------

 // Promise sql 
// https://metanit.com/web/nodejs/8.3.php
// --------------------------------------

// 2 

// chaining in nodejs
/*

{
  "first_name": "TestName",
  "last_name": "TestSurneme",
  "email": "test@test.ru",
  "user_password": "12345",
  "sex": "female",
  "image_url": "./img/api"
}

{
  "first_name": "TestName",
  "email": "test@test.ru",
  "user_password": "12345",
}

update
{
  "first_name": "TestName",
  "last_name": "TestSurneme",
  "email": "test@test.ru",
  "sex": "female",
  "image_url": "./img/api"
}

login
{
  "first_name": "TestName",
  "email": "test@test.ru",
  "user_password": "12345"
}
// TODO change users to profiles in routes 
*/
// ❓ try catch? / promises почему нет ?
// ❓ нужен ли обычный create-user если есть procedure ? поискать по файлам

// ❓ Пол (Мужской, Женский),  / - может они булин хотят?

// ❓ запрет на редактирование - достаточно просто огараничить кол-во вводимых переменных???
// ❓ return or not return?
// ❓ регистрация === авторизация может ли Сева идти к ЯЧЕЙКЕ? 


// проверить updateuser ответ на лету или нет?



// -------------------------------------

// export const getUsers = (req, res) => {
//     logger.info(`${req.method} ${req.originalUrl}, fetching users`);
//     database.query(QUERY.SELECT_USERS, (error, results) => {
//         if (!results) {
//             res.send(new Response(HttpStatus.OK.code, HttpStatus.OK.status, `No users found`));
//         } else {
//             res.send(new Response(HttpStatus.OK.code, HttpStatus.OK.status, `Users retrieved`, {
//                 users: results
//             }));
//         }
//     });
// };

// export const createUser = (req, res) => {
//     logger.info(`${req.method} ${req.originalUrl}, creating user`);
//     database.query(QUERY.CREATE_USER_PROCEDURE, Object.values(req.body), (error, results) => {
//         if (!results) {
//             logger.error(error.message);
//             res.send(new Response(HttpStatus.INTERNAL_SERVER_ERROR.code, HttpStatus.INTERNAL_SERVER_ERROR.status, `Error occurred`));
//         } else {
//             const user = results[0][0];
//             res.status(HttpStatus.CREATED.code)
//                 .send(new Response(HttpStatus.CREATED.code, HttpStatus.CREATED.status, `User created`, {
//                     user
//                 }));
//         }
//     });
// };

// export const getUser = (req, res) => {
//     logger.info(`${req.method} ${req.originalUrl}, fetching user`);
//     database.query(QUERY.SELECT_USER, [req.params.id], (error, results) => {
//         if (!results[0]) {
//             res.send(new Response(HttpStatus.NOT_FOUND.code, HttpStatus.NOT_FOUND.status, `User by id ${req.params.id} was not found`));
//         } else {
//             res.send(new Response(HttpStatus.OK.code, HttpStatus.OK.status, `User retrieved`, results[0]));
//         }
//     });
// };

// export const updateUser = (req, res) => {
//     logger.info(`${req.method} ${req.originalUrl}, fetching user`);

//     database.query(QUERY.SELECT_USER, [req.params.id], (error, results) => {
//         if (!results[0]) {
//             res.send(new Response(HttpStatus.NOT_FOUND.code, HttpStatus.NOT_FOUND.status, `User by id ${req.params.id} was not found`));
//         } else {
//             logger.info(`${req.method} ${req.originalUrl}, updating user`);
//             database.query(QUERY.UPDATE_USER, [...Object.values(req.body), req.params.id], (error, results) => {
//                 if (!error) {
//                     res.send(new Response(HttpStatus.OK.code, HttpStatus.OK.status, `User updated`, {
//                         id: req.params.id,
//                         ...req.body
//                     }));
//                 } else {
//                     logger.error(error.message);
//                     res.send(new Response(HttpStatus.INTERNAL_SERVER_ERROR.code, HttpStatus.INTERNAL_SERVER_ERROR.status, `Error occurred`));
//                 }
//             });
//         }
//     });
// };

  // async getUsers(req, res) {
    //     try {
    //         logger.info(`${req.method} ${req.originalUrl}, fetching users`);
    //         database.query(QUERY.SELECT_USERS, (error, results) => {
    //             if (!results) {
    //                 res.send(new ServerCustomResponse(200, 'OK', `No users found`));
    //             } else {
    //                 res.send(new ServerCustomResponse(200, 'OK', `Users retrieved`, {
    //                     users: results
    //                 }));
    //             }
    //         });
    //     } catch (error) {
    //         res.send(new ServerCustomResponse(500, 'INTERNAL_SERVER_ERROR', `Internal server error`));
    //     }
    // }


    // 1 - в документации - функция сама выбрасывает исключения:

    // 1.0 Sync – если есть ошибка то точно поймаем через try catch
    
    
    // 1.1 callback НЕ ВЫБРАСВЫВАЕЮТ сами - там другой механизм !! (error, result)
    // 1.2 асинхронные сами НЕ ВЫБРАСВАЮТ - then catch
    // 1.3 асинхрон можно заставить выбрасывать через async await
    // 1.4 в ноде пости все фунц имеют 4 вар использования:
      // - Sync 
      // - Async:
          // 1- Callback
          // 2- then cacth
          // 3 - async awat

    // 2 - сами выбрасываем (внутри функйии)  через throw

    // Идеальный код 
    // использую трай катч те и Не использую  кол быки и then catch

    // если есть решение с callback то 99 проц должно быть с промисом!
    // как прврерить есть ли у фунция вернет промис - console log
    // если не вернула промис, то может быть есть похожая фунция (fs и fsPromice)
    // в крайнем случае можно выполнить прмософикацию самому 

    // call back - это тоже  паралльльная фунц
    // fs.readFile('ddd', function(err, res) {

    // })

    // function readFilePromise(name) {
    //   return new Promise(function(resolve, reject) {
    //     fs.readFile('ddd', function(err, res) {
    //       if (err) {
    //         reject();
    //       } else {
    //         resolve(res);
    //       }
    //     })
    //   }
    // }